package com.example.myapplication.adapter;

/**
 * Created by Naaz on 10/27/2020.
 */

import android.content.Context;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.R;
import com.example.myapplication.models.ImageResult;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class GridViewAdapter extends ArrayAdapter<String> {

    public GridViewAdapter(Context context, ArrayList<String> images) {
        super(context, R.layout.image_item, images);
    }

    /**
     * Override getView and use Picasso to retrieve image
     *
     * @param position
     * @param convertView
     * @param parent
     * @return convertView
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        String image = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.image_item, parent, false);
        }
        // Lookup view for data population
        ImageView ivThumbnail = (ImageView) convertView.findViewById(R.id.ivThumbnail);
        TextView tvTitle = (TextView) convertView.findViewById(R.id.tvTitle);
        // Populate the data into the template view using the data object (formats the HTML)
      //  tvTitle.setText(Html.fromHtml(image.getTitle()));
        // Clear out image in case of view is recycled
        ivThumbnail.setImageResource(0);
        // Use Picassi to retrieve image
        Picasso.with(getContext()).load(image).into(ivThumbnail);
        return convertView;
    }
}
