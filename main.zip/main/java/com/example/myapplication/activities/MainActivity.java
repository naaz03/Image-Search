package com.example.myapplication.activities;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.telecom.Call;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.example.myapplication.adapter.GridViewAdapter;
import com.example.myapplication.models.ImageResult;


import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


import com.example.myapplication.listener.EndlessScrollListener;

import com.squareup.picasso.Downloader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class MainActivity extends AppCompatActivity {

    private final int REQUEST_CODE = 1;

    private EditText etSearchField;
    private GridView gvResults;
    private ArrayList<String> resultArrayList= new ArrayList<String>();
    String url="";

    private GridViewAdapter gridAdapter;
    private static String TAG = MainActivity.class.getCanonicalName();

    // URLs for search query and parameters
    private String googleImageURL = "https://ajax.googleapis.com/ajax/services/search/images?v=1.0&q=";
    private int start = 0;
    private String query = "";
    private String rsz = "&rsz=8";
    private final String p_imagesize = "&imgsz=";
    private final String p_imagecolor = "&imgcolor=";
    private final String p_imagetype = "&imgtype=";
    private final String p_sitefilter = "&as_sitesearch=";
    private final String p_start = "&start=";
    StringBuffer full_query = new StringBuffer();
    String searchText;

    // Variables to store search filters
    private int imagesize_val = 0;
    private int imagecolor_val = 0;
    private int imagetype_val = 0;
    private String sitefilter_val = "";
    private String[] image_size_array;
    private String[] color_filter_array;
    private String[] image_type_array;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnSearch = (Button)findViewById(R.id.btnSearch);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchText = ((EditText)findViewById(R.id.etSearchField)).getText().toString();
                 url= "https://www.google.co.in/search?biw=1366&bih=675&tbm=isch&sa=1&ei=qFSJWsuTNc-wzwKFrZHoCw&q="+searchText;

                // observable
                Observable<ArrayList<String>> animalsObservable = getAnimalsObservable();

                // observer
                Observer<ArrayList<String>> animalsObserver = getAnimalsObserver();
                // observer subscribing to observable
                animalsObservable
                        .observeOn(Schedulers.io())
                        .subscribeOn(AndroidSchedulers.mainThread())
                        .subscribe(animalsObserver);

//                AsyncTask.execute(new Runnable() {
//                    @Override
//                    public void run() {
//                        Log.i("someething" , "something");
//                        getImages(url);
//                    }
//                });
//                final Handler handler = new Handler(Looper.getMainLooper());
//                handler.postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        //Do something after 100ms
//                        setUp(resultArrayList);
//                    }
//                }, 1000);

            }
        });



    }
    private Observer<ArrayList<String>> getAnimalsObserver() {
        return new Observer<ArrayList<String>>() {
            @Override
            public void onSubscribe(Disposable d) {
                Log.d(TAG, "onSubscribe");
            }

            @Override
            public void onNext(ArrayList<String> s) {
                Log.d(TAG, "Name: " + s);
                setUp(s);
            }

            @Override
            public void onError(Throwable e) {
                Log.e(TAG, "onError: " + e.getMessage());
            }

            @Override
            public void onComplete() {
                Log.d(TAG, "All items are emitted!");
                setUp(resultArrayList);
            }
        };
    }




    private void getImages(String url) {
        Document doc = null;
        try{
            doc = Jsoup.connect(url).get();
        }catch (IOException e){
            e.printStackTrace();
        }
        Elements imgs = doc.select("img");
        System.out.println("Damn images"+imgs);
        for (Element img : imgs){
            Log.d("image-src", img.attr("data-src"));//changed `src` to `data-src`
            //resultArrayList.add(img);
            //JSONArray image_json = null;

                    resultArrayList.add(img.attr("data-src"));


        }


    }
    private Observable<ArrayList<String>> getAnimalsObservable() {
//        AsyncTask.execute(new Runnable() {
//                    @Override
//                    public void run() {
//                        Log.i("someething" , "something");
                        getImages(url);
//                    }
//                });

        return Observable.just(resultArrayList);
    }

    /**
     * Set up adapters and listeners for activity, called during onCreate
     * Includes listener to launch FullScreenActivity when an image is clicked
     * Includes listener for endless scrolling
     * @param resultArrayList
     */
    public void setUp(ArrayList<String> resultArrayList){
        etSearchField = (EditText) findViewById(R.id.etSearchField);
        gvResults = (GridView) findViewById(R.id.gvResults);
        // Attach datasource to GridAdapter
        gridAdapter = new GridViewAdapter(this, this.resultArrayList);
        gvResults.setAdapter(gridAdapter);
        // Launch full screen activity to display picture in screen
        gvResults.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(MainActivity.this, FullScreenActivity.class);
                i.putExtra("image", MainActivity.this.resultArrayList.get(position));
                startActivity(i);
            }
        });
        color_filter_array = getResources().getStringArray(R.array.color_filter_array);
        image_size_array = getResources().getStringArray(R.array.image_size_array);
        image_type_array = getResources().getStringArray(R.array.image_type_array);
        // Provide infinite scrolling ability
        gvResults.setOnScrollListener(new EndlessScrollListener() {
            @Override
            public void onLoadMore(int page, int totalItemsCount) {
                start += 8;
                fetchPopularPhotos(query, start);
            }
        });
    }

    /**
     * Launch SettingsActivity to toggle search filters
     * Passes existing search filters to SettingsActivity in a bundle
     *
     * @param mi
     */
    public void onComposeAction(MenuItem mi){
        Intent i = new Intent(MainActivity.this, SettingsActivity.class);
        i.putExtra("ImageSize", imagesize_val);
        i.putExtra("ColorFilter", imagecolor_val);
        i.putExtra("ImageType", imagetype_val);
        i.putExtra("SiteFilter", sitefilter_val);
        startActivityForResult(i, REQUEST_CODE);
    }

    /**
     * Obtain new search filters from MenuItem selection
     *
     * @param requestCode
     * @param resultCode
     * @param settings
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent settings){
        if(resultCode == RESULT_OK && requestCode == REQUEST_CODE){
            imagesize_val = settings.getExtras().getInt("ImageSize");
            imagecolor_val = settings.getExtras().getInt("ColorFilter");
            imagetype_val = settings.getExtras().getInt("ImageType");
            sitefilter_val = settings.getExtras().getString("SiteFilter");
            Toast.makeText(this, "Settings updated", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    /**
     * Query for photos when search button is clicked
     *
     * @param v search button view
     */
    public void onImageSearch(View v){
        query = etSearchField.getText().toString();
        // Launch a toast to let user know search made
        Toast.makeText(this, "Searching for: " + query, Toast.LENGTH_SHORT).show();
        gridAdapter.clear();
        start = 0;
        fetchPopularPhotos(query, start);
    }

    /**
     * Fetches photos base on query, page and search filters from Google
     *
     * @param query query string
     * @param page page to retrieve
     */
    public void fetchPopularPhotos(String query, int page){
                        // Create query string to be sent to Google


//       full_query.append(googleImageURL);
//        full_query.append(query);
//       full_query.append(rsz);
//        full_query.append(p_imagesize + image_size_array[imagesize_val]);
//        full_query.append(p_imagecolor + color_filter_array[imagecolor_val]);
//       full_query.append(p_imagetype + image_type_array[imagetype_val]);
//       full_query.append(p_sitefilter + sitefilter_val);
//        full_query.append(p_start + page);
//        try {
//            run();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        AsyncHttpClient client = new AsyncHttpClient();
//        // Create query string to be sent to Google
//        StringBuffer full_query = new StringBuffer();
//////////        full_query.append(googleImageURL);
//////////        full_query.append(query);
//////////        full_query.append(rsz);
//////////        full_query.append(p_imagesize + image_size_array[imagesize_val]);
//////////        full_query.append(p_imagecolor + color_filter_array[imagecolor_val]);
//////////        full_query.append(p_imagetype + image_type_array[imagetype_val]);
//////////        full_query.append(p_sitefilter + sitefilter_val);
//////////        full_query.append(p_start + page);
//        client.get(full_query.toString(), null, new JsonHttpResponseHandler() {
//            @Override
//            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
//                JSONArray image_json = null;
//                try {
//                    image_json = response.getJSONObject("responseData").getJSONArray("results");
//                    gridAdapter.addAll(ImageResult.parseJSON(image_json));
//                } catch (JSONException je) {
//                    Log.d("DEBUG JSON", je.toString());
//                }
//            }
//            @Override
//            public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
//                Log.d("DEBUG JSON", statusCode + " " + errorResponse.toString());
//            }
//        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    void run() throws IOException {

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(full_query.toString())
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(okhttp3.Call call, IOException e) {
                call.cancel();
            }

            @Override
            public void onResponse(okhttp3.Call call, Response response) throws IOException {
                final String myResponse = response.body().string();

                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //txtString.setText(myResponse);
                    }
                });
            }


        });
    }

}

